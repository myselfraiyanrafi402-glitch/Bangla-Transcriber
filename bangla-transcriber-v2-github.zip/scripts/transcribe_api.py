#!/usr/bin/env python3
"""API-only Bangla transcription helper; no Hugging Face/local model downloads."""
from __future__ import annotations
import argparse, json, os, re, shutil, subprocess, sys
from pathlib import Path
from typing import Any
import requests

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

def srt_time(seconds: float) -> str:
    ms = max(0, round(seconds * 1000))
    h, ms = divmod(ms, 3_600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"

def duration_seconds(path: Path):
    ffprobe = shutil.which("ffprobe")
    if not ffprobe: return None
    try:
        p = subprocess.run([ffprobe, "-v", "error", "-show_entries", "format=duration",
                            "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
                           capture_output=True, text=True, check=True)
        return float(p.stdout.strip())
    except Exception:
        return None

def call_api(path: Path, url: str, key: str, model: str):
    headers = {"Authorization": f"Bearer {key}"}
    data = {"model": model, "language": "bn", "response_format": "verbose_json"}
    with path.open("rb") as f:
        r = requests.post(url, headers=headers, data=data,
                          files={"file": (path.name, f)}, timeout=1800)
    r.raise_for_status()
    if "json" in r.headers.get("content-type", ""):
        payload = r.json()
        transcript = str(payload.get("text", "")).strip()
        segs = payload.get("segments")
        segments = None
        if isinstance(segs, list):
            segments = [{"start": float(x["start"]), "end": float(x["end"]),
                         "text": str(x.get("text", "")).strip()}
                        for x in segs if isinstance(x, dict) and "start" in x and "end" in x]
        if not transcript and segments:
            transcript = " ".join(x["text"] for x in segments)
        if not transcript: raise RuntimeError("API response did not contain transcript text.")
        return transcript, segments
    transcript = r.text.strip()
    if not transcript: raise RuntimeError("API returned an empty transcript.")
    return transcript, None

def estimate_segments(text: str, duration: float):
    sentences = [x.strip() for x in re.split(r"(?<=[।.!?])\\s+", text) if x.strip()]
    chunks = []
    for sentence in sentences or [text]:
        words, current = sentence.split(), []
        for word in words:
            if current and len(" ".join(current + [word])) > 72:
                chunks.append(" ".join(current)); current = [word]
            else: current.append(word)
        if current: chunks.append(" ".join(current))
    if not chunks: return []
    weights = [max(1, len(x)) for x in chunks]; total = sum(weights)
    cursor, out = 0.0, []
    for chunk, weight in zip(chunks, weights):
        end = min(duration, cursor + duration * weight / total)
        out.append({"start": cursor, "end": max(cursor + 0.4, end), "text": chunk})
        cursor = end
    out[-1]["end"] = max(out[-1]["end"], duration)
    return out

def to_srt(segments):
    blocks = []
    for i, seg in enumerate(segments, 1):
        start, end = float(seg["start"]), max(float(seg["end"]), float(seg["start"]) + .25)
        blocks.append(f"{i}\\n{srt_time(start)} --> {srt_time(end)}\\n{seg['text'].strip()}")
    return "\\n\\n".join(blocks) + "\\n"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("--output-dir", type=Path, default=Path("output"))
    ap.add_argument("--burn-in", action="store_true")
    ap.add_argument("--font-file")
    args = ap.parse_args()
    src = args.input.resolve()
    if not src.is_file(): ap.error(f"Input file not found: {src}")
    url = os.getenv("TRANSCRIBE_API_URL", "https://api.openai.com/v1/audio/transcriptions")
    key = os.getenv("TRANSCRIBE_API_KEY", "")
    model = os.getenv("TRANSCRIBE_API_MODEL", "whisper-1")
    if not key:
        print("Set TRANSCRIBE_API_KEY before running. No API key is bundled.", file=sys.stderr); return 2
    args.output_dir.mkdir(parents=True, exist_ok=True)
    text, segments = call_api(src, url, key, model)
    duration = duration_seconds(src)
    estimated = False
    timing = "recognizer"
    if not segments:
        if duration:
            segments = estimate_segments(text, duration); estimated = True; timing = "estimated"
        else:
            segments = []; timing = "unavailable"
    stem = src.stem
    (args.output_dir / f"{stem}.txt").write_text(
        f"Timing: {timing}" + (" (ESTIMATED; not speech-aligned)" if estimated else "") +
        "\\n\\n" + text + "\\n", encoding="utf-8")
    payload = {"source_file": src.name, "language": "bn", "backend": "api",
               "timing": timing, "estimated_timing": estimated,
               "duration_seconds": duration, "text": text, "segments": segments}
    (args.output_dir / f"{stem}.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    if segments:
        srt = args.output_dir / f"{stem}.srt"
        srt.write_text(to_srt(segments), encoding="utf-8")
        if args.burn_in:
            ffmpeg = shutil.which("ffmpeg")
            if not ffmpeg: raise RuntimeError("FFmpeg not found; SRT was still exported.")
            out = args.output_dir / f"{stem}_subtitled.mp4"
            sub = str(srt.resolve()).replace("\\\\", "\\\\\\\\").replace(":", "\\\\:")
            vf = f"subtitles='{sub}'"
            subprocess.run([ffmpeg, "-y", "-i", str(src), "-vf", vf, "-c:a", "copy", str(out)], check=True)
    print(f"Transcription exports saved in: {args.output_dir.resolve()}")
    return 0

if __name__ == "__main__":
    try: raise SystemExit(main())
    except requests.RequestException as e:
        print(f"Transcription API request failed: {e}", file=sys.stderr); raise SystemExit(3)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr); raise SystemExit(4)
