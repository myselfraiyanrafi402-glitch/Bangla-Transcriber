---
name: bangla-transcriber-v2
description: Transcribe uploaded Bangla or Bangla-English audio/video using a configured online transcription API, then clean the transcript and export TXT, JSON, and SRT subtitles. Optionally burn subtitles into a video when supported.
---

# Bangla Transcriber V2 — Claude.ai browser edition

## Purpose
Process user-uploaded Bangla / Bangla-English audio or video and produce a faithful transcript and subtitle files. This edition does NOT download Whisper from Hugging Face and does NOT require a local Whisper model.

## Required workflow
1. Confirm the uploaded media is accessible in the current Claude conversation and identify its type.
2. Extract or access the audio using tools available in the current Claude.ai code-execution environment.
3. Use a configured online speech-to-text API only if:
   - the environment has network access;
   - the user has supplied/configured an API endpoint and key in the approved runtime environment; and
   - the API supports audio upload and Bangla transcription.
4. If network access or credentials are unavailable, do not pretend to transcribe. Explain the missing requirement and ask the user to provide a transcript/SRT or configure an API route.
5. Do not try Hugging Face, `faster-whisper`, or model downloads in this browser edition.

## Transcription rules
- Default language: Bangla (`bn`).
- Preserve Bangla script and spoken English words/code-switching.
- Preserve colloquial Bangladeshi Bangla.
- Do not translate unless requested.
- Do not invent unclear words. Mark uncertain portions as `[অস্পষ্ট]`.
- Take care with Bangladeshi names, places, brands, numbers, and scholarship amounts. Flag uncertainty instead of guessing.
- Keep a faithful transcript. Only remove fillers/repetitions if the user asks for a cleaned version.
- Add punctuation and paragraph breaks without changing meaning.

## Outputs
When transcription succeeds, create:
- `.txt`: transcript;
- `.json`: transcript and segment metadata;
- `.srt`: subtitle cues using API-provided timestamps whenever possible.
- Optional subtitled video only when requested and FFmpeg plus a Bangla-capable font are available.

If the API returns plain text without timestamps:
- do not claim timestamps are accurate;
- if media duration is available, optionally create estimated cue timing;
- label timing as `estimated` in JSON and in the TXT header;
- otherwise provide TXT only and ask for timestamped text or permission to estimate.

## Subtitle formatting
- Use SRT timestamps `HH:MM:SS,mmm`.
- Keep cues chronological and non-overlapping.
- Prefer natural phrase boundaries and a maximum of two readable lines per cue.
- Avoid splitting names or connected phrases.
- Use recognizer timestamps where available.

## API configuration
The companion script in `scripts/transcribe_api.py` expects:
- `TRANSCRIBE_API_URL`
- `TRANSCRIBE_API_KEY`
- `TRANSCRIBE_API_MODEL` (optional; default `whisper-1`)

The default example endpoint is the OpenAI audio transcription endpoint. A compatible provider may use a different request/response schema; check its documentation before use. Never expose or commit API keys.

## Important Claude.ai limitation
A GitHub repository hosts this skill's files; it does not host or run the speech model for Claude. Claude.ai Skills run within a managed environment whose network access and available packages can vary. This skill cannot bypass network restrictions, create API credentials, or guarantee FFmpeg/model execution. Be transparent about failures.

## User interaction
If the user uploads media and asks for subtitles, start with that media. Ask only for essential missing details. Default to faithful Bangla subtitles, TXT + JSON + SRT, and no burned-in video unless requested.
