# Bangla Transcriber V2 — GitHub edition for Claude.ai

This repository contains a Claude custom Skill plus an optional API-based transcription helper. It is designed to avoid Hugging Face model downloads.

## Key point: GitHub is not the speech-recognition engine

GitHub stores the skill instructions and source code. It does not transcribe audio. This edition sends audio to a configured online transcription API (example: OpenAI Audio Transcriptions API). You need an API key and network access from the runtime. Claude.ai network access can vary by environment/settings.

This version deliberately removes the `faster-whisper` / Hugging Face download path.

## Features
- Bangla and Bangla-English transcription via configured API
- Faithful Bangla text cleanup guidance
- TXT, JSON, and SRT exports
- Uses provider timestamps if returned
- Clearly labels estimated timing when the provider returns text only
- Optional FFmpeg subtitle burn-in (local helper only)

## Add to Claude.ai
1. Download the ZIP from the GitHub repository (or this release).
2. In Claude.ai, open **Customize → Skills**.
3. Choose **Create skill → Upload a skill**.
4. Upload the ZIP and enable the skill.

Claude's custom Skills require code execution/file creation to be enabled. The exact menus can vary. See [Anthropic's Skills guide](https://support.claude.com/en/articles/12512180-use-skills-in-claude).

## Important: API setup
The skill does not contain a private API key. Do not place keys in `SKILL.md`, commit them to GitHub, or upload them in a public repository.

For the optional local helper, set these environment variables:

```bash
TRANSCRIBE_API_URL=https://api.openai.com/v1/audio/transcriptions
TRANSCRIBE_API_KEY=your-secret-key
TRANSCRIBE_API_MODEL=whisper-1
```

Then install dependencies and run:

```bash
pip install -r requirements.txt
python scripts/transcribe_api.py your-video.mp4 --output-dir output
```

The script uploads the audio/video file to the API. Review the provider's accepted file formats, file-size limits, supported languages, privacy terms, and billing before use.

## Claude.ai browser limitation
A Skill is a set of instructions and supporting files. It does not automatically give Claude a new speech model. The browser environment may or may not have network access to the API, and may not have FFmpeg or arbitrary packages. If the API cannot be reached or credentials are unavailable, Claude must ask for a transcript/SRT or a working API configuration instead of inventing subtitles.

## Repository contents

```text
bangla-transcriber-v2-github/
├── SKILL.md
├── README.md
├── requirements.txt
├── .env.example
├── .gitignore
├── LICENSE
├── scripts/
│   └── transcribe_api.py
└── examples/
    └── sample-output.json
```
